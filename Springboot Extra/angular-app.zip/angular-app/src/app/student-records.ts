import { Student } from './student';

export const STUDENTS: Student[] = [
  { id: 101, name: 'Sundar', age: 55 },
  { id: 102, name: 'John', age: 45 },
  { id: 103, name: 'Bob', age: 36 }
];