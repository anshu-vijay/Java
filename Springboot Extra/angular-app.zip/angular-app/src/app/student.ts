export class Student{
    id: number;
    age: number;
    name: string;
}